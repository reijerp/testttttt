function link(url) {
    window.location.href = url;
}